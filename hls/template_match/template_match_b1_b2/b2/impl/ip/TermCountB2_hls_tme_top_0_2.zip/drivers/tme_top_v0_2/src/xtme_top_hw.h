// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// CTRL
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of patch_w
//        bit 15~0 - patch_w[15:0] (Read/Write)
//        others   - reserved
// 0x14 : reserved
// 0x18 : Data signal of patch_h
//        bit 15~0 - patch_h[15:0] (Read/Write)
//        others   - reserved
// 0x1c : reserved
// 0x20 : Data signal of templ_w
//        bit 15~0 - templ_w[15:0] (Read/Write)
//        others   - reserved
// 0x24 : reserved
// 0x28 : Data signal of templ_h
//        bit 15~0 - templ_h[15:0] (Read/Write)
//        others   - reserved
// 0x2c : reserved
// 0x30 : Data signal of result_score
//        bit 31~0 - result_score[31:0] (Read)
// 0x34 : Control signal of result_score
//        bit 0  - result_score_ap_vld (Read/COR)
//        others - reserved
// 0x40 : Data signal of result_x
//        bit 15~0 - result_x[15:0] (Read)
//        others   - reserved
// 0x44 : Control signal of result_x
//        bit 0  - result_x_ap_vld (Read/COR)
//        others - reserved
// 0x50 : Data signal of result_y
//        bit 15~0 - result_y[15:0] (Read)
//        others   - reserved
// 0x54 : Control signal of result_y
//        bit 0  - result_y_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XTME_TOP_CTRL_ADDR_AP_CTRL           0x00
#define XTME_TOP_CTRL_ADDR_GIE               0x04
#define XTME_TOP_CTRL_ADDR_IER               0x08
#define XTME_TOP_CTRL_ADDR_ISR               0x0c
#define XTME_TOP_CTRL_ADDR_PATCH_W_DATA      0x10
#define XTME_TOP_CTRL_BITS_PATCH_W_DATA      16
#define XTME_TOP_CTRL_ADDR_PATCH_H_DATA      0x18
#define XTME_TOP_CTRL_BITS_PATCH_H_DATA      16
#define XTME_TOP_CTRL_ADDR_TEMPL_W_DATA      0x20
#define XTME_TOP_CTRL_BITS_TEMPL_W_DATA      16
#define XTME_TOP_CTRL_ADDR_TEMPL_H_DATA      0x28
#define XTME_TOP_CTRL_BITS_TEMPL_H_DATA      16
#define XTME_TOP_CTRL_ADDR_RESULT_SCORE_DATA 0x30
#define XTME_TOP_CTRL_BITS_RESULT_SCORE_DATA 32
#define XTME_TOP_CTRL_ADDR_RESULT_SCORE_CTRL 0x34
#define XTME_TOP_CTRL_ADDR_RESULT_X_DATA     0x40
#define XTME_TOP_CTRL_BITS_RESULT_X_DATA     16
#define XTME_TOP_CTRL_ADDR_RESULT_X_CTRL     0x44
#define XTME_TOP_CTRL_ADDR_RESULT_Y_DATA     0x50
#define XTME_TOP_CTRL_BITS_RESULT_Y_DATA     16
#define XTME_TOP_CTRL_ADDR_RESULT_Y_CTRL     0x54

