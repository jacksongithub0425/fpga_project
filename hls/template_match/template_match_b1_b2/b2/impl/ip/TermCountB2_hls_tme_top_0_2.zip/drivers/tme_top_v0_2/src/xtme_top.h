// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XTME_TOP_H
#define XTME_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xtme_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Ctrl_BaseAddress;
} XTme_top_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XTme_top;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XTme_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XTme_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XTme_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XTme_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XTme_top_Initialize(XTme_top *InstancePtr, UINTPTR BaseAddress);
XTme_top_Config* XTme_top_LookupConfig(UINTPTR BaseAddress);
#else
int XTme_top_Initialize(XTme_top *InstancePtr, u16 DeviceId);
XTme_top_Config* XTme_top_LookupConfig(u16 DeviceId);
#endif
int XTme_top_CfgInitialize(XTme_top *InstancePtr, XTme_top_Config *ConfigPtr);
#else
int XTme_top_Initialize(XTme_top *InstancePtr, const char* InstanceName);
int XTme_top_Release(XTme_top *InstancePtr);
#endif

void XTme_top_Start(XTme_top *InstancePtr);
u32 XTme_top_IsDone(XTme_top *InstancePtr);
u32 XTme_top_IsIdle(XTme_top *InstancePtr);
u32 XTme_top_IsReady(XTme_top *InstancePtr);
void XTme_top_EnableAutoRestart(XTme_top *InstancePtr);
void XTme_top_DisableAutoRestart(XTme_top *InstancePtr);

void XTme_top_Set_patch_w(XTme_top *InstancePtr, u32 Data);
u32 XTme_top_Get_patch_w(XTme_top *InstancePtr);
void XTme_top_Set_patch_h(XTme_top *InstancePtr, u32 Data);
u32 XTme_top_Get_patch_h(XTme_top *InstancePtr);
void XTme_top_Set_templ_w(XTme_top *InstancePtr, u32 Data);
u32 XTme_top_Get_templ_w(XTme_top *InstancePtr);
void XTme_top_Set_templ_h(XTme_top *InstancePtr, u32 Data);
u32 XTme_top_Get_templ_h(XTme_top *InstancePtr);
u32 XTme_top_Get_result_score(XTme_top *InstancePtr);
u32 XTme_top_Get_result_score_vld(XTme_top *InstancePtr);
u32 XTme_top_Get_result_x(XTme_top *InstancePtr);
u32 XTme_top_Get_result_x_vld(XTme_top *InstancePtr);
u32 XTme_top_Get_result_y(XTme_top *InstancePtr);
u32 XTme_top_Get_result_y_vld(XTme_top *InstancePtr);

void XTme_top_InterruptGlobalEnable(XTme_top *InstancePtr);
void XTme_top_InterruptGlobalDisable(XTme_top *InstancePtr);
void XTme_top_InterruptEnable(XTme_top *InstancePtr, u32 Mask);
void XTme_top_InterruptDisable(XTme_top *InstancePtr, u32 Mask);
void XTme_top_InterruptClear(XTme_top *InstancePtr, u32 Mask);
u32 XTme_top_InterruptGetEnabled(XTme_top *InstancePtr);
u32 XTme_top_InterruptGetStatus(XTme_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
