// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xtme_top.h"

extern XTme_top_Config XTme_top_ConfigTable[];

#ifdef SDT
XTme_top_Config *XTme_top_LookupConfig(UINTPTR BaseAddress) {
	XTme_top_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XTme_top_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XTme_top_ConfigTable[Index].Ctrl_BaseAddress == BaseAddress) {
			ConfigPtr = &XTme_top_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XTme_top_Initialize(XTme_top *InstancePtr, UINTPTR BaseAddress) {
	XTme_top_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XTme_top_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XTme_top_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XTme_top_Config *XTme_top_LookupConfig(u16 DeviceId) {
	XTme_top_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XTME_TOP_NUM_INSTANCES; Index++) {
		if (XTme_top_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XTme_top_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XTme_top_Initialize(XTme_top *InstancePtr, u16 DeviceId) {
	XTme_top_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XTme_top_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XTme_top_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

