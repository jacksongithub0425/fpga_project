// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xtme_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XTme_top_CfgInitialize(XTme_top *InstancePtr, XTme_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XTme_top_Start(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_AP_CTRL) & 0x80;
    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XTme_top_IsDone(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XTme_top_IsIdle(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XTme_top_IsReady(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XTme_top_EnableAutoRestart(XTme_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_AP_CTRL, 0x80);
}

void XTme_top_DisableAutoRestart(XTme_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_AP_CTRL, 0);
}

void XTme_top_Set_patch_w(XTme_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_PATCH_W_DATA, Data);
}

u32 XTme_top_Get_patch_w(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_PATCH_W_DATA);
    return Data;
}

void XTme_top_Set_patch_h(XTme_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_PATCH_H_DATA, Data);
}

u32 XTme_top_Get_patch_h(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_PATCH_H_DATA);
    return Data;
}

void XTme_top_Set_templ_w(XTme_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_TEMPL_W_DATA, Data);
}

u32 XTme_top_Get_templ_w(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_TEMPL_W_DATA);
    return Data;
}

void XTme_top_Set_templ_h(XTme_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_TEMPL_H_DATA, Data);
}

u32 XTme_top_Get_templ_h(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_TEMPL_H_DATA);
    return Data;
}

u32 XTme_top_Get_result_score(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_RESULT_SCORE_DATA);
    return Data;
}

u32 XTme_top_Get_result_score_vld(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_RESULT_SCORE_CTRL);
    return Data & 0x1;
}

u32 XTme_top_Get_result_x(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_RESULT_X_DATA);
    return Data;
}

u32 XTme_top_Get_result_x_vld(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_RESULT_X_CTRL);
    return Data & 0x1;
}

u32 XTme_top_Get_result_y(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_RESULT_Y_DATA);
    return Data;
}

u32 XTme_top_Get_result_y_vld(XTme_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_RESULT_Y_CTRL);
    return Data & 0x1;
}

void XTme_top_InterruptGlobalEnable(XTme_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_GIE, 1);
}

void XTme_top_InterruptGlobalDisable(XTme_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_GIE, 0);
}

void XTme_top_InterruptEnable(XTme_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_IER);
    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_IER, Register | Mask);
}

void XTme_top_InterruptDisable(XTme_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_IER);
    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_IER, Register & (~Mask));
}

void XTme_top_InterruptClear(XTme_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTme_top_WriteReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_ISR, Mask);
}

u32 XTme_top_InterruptGetEnabled(XTme_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_IER);
}

u32 XTme_top_InterruptGetStatus(XTme_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XTme_top_ReadReg(InstancePtr->Ctrl_BaseAddress, XTME_TOP_CTRL_ADDR_ISR);
}

